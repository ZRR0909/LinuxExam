package com.example.notepad.bean;

public class NotepadBean {
    private String id;
    private String notepadname;
    private String notepadtime;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNotepadname() {
        return notepadname;
    }

    public void setNotepadname(String notepadname) {
        this.notepadname = notepadname;
    }

    public String getNotepadtime() {
        return notepadtime;
    }

    public void setNotepadtime(String notepadtime) {
        this.notepadtime = notepadtime;
    }

    @Override
    public String toString() {
        return "NotepadBean{" +
                "id='" + id + '\'' +
                ", notepadname='" + notepadname + '\'' +
                ", notepadtime='" + notepadtime + '\'' +
                '}';
    }
}
